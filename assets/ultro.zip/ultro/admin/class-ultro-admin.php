<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://www.ultro.io/
 * @since      1.0.0
 *
 * @package    Ultro
 * @subpackage Ultro/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Ultro
 * @subpackage Ultro/admin
 * @author     Ultro <rahul@ultro.io>
 */
class Ultro_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		$this->enqueue_styles();
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Ultro_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Ultro_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/ultro-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Ultro_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Ultro_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/ultro-admin.js', array( 'jquery' ), $this->version, false );

	}

	/**
	 * Register the Menu for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function create_menu() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Ultro_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Ultro_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

	    add_menu_page( 'Ultro.io', 'Ultro.io', 'manage_options', 'ultro', array(&$this, 'render_ultro_admin_page'), plugins_url( 'ultro/images/icon.png' ), 10);

	}

	public function render_ultro_admin_page() {
		global $title;

	    print '<div class="wrap">';

	    $file = plugin_dir_path( __FILE__ ) . "/partials/ultro-admin-display.php";

	    if ( file_exists( $file ) )
	        require $file;

	    print '</div>';
	}

	public function save_ultro_script() {
		$widget_id = $_POST['widgetId'];

		$script = "<!-- Start of Async Ultro Code -->
		<script>
		!function(){
		var t=document.createElement('script');
		t.type='text/javascript',t.async=!0,t.setAttribute('id','ultro-widget-script'),t.setAttribute('data-widget-id',
		'".$widget_id."'),
		t.src='https://dev-backend.ultro.io/static/sdk.js';document.body.appendChild(t);
		}();
		</script>
		<!-- End of Async Ultro Code -->";

		update_option('ultro_script_code', $script);
		update_option('ultro_selected_widget_id', $widget_id);
		echo "true";
		die();
	}
}