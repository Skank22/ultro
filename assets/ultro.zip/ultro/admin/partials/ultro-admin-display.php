<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://www.ultro.io/
 * @since      1.0.0
 *
 * @package    Ultro
 * @subpackage Ultro/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="ultro-admin-page">
	<div class="header">
		<div class="ultro-logo">
			<img src="https://dev.ultro.io/assets/images/logo-large.png" width="90px" height="90px">
		</div>
		<div class="success_msg">
			Done
		</div>
	</div>
	<div class="login-wrapper">
		<div class="login-page">
		  <div class="form">
		    <div class="login-form">
		      <input type="text" id="username" placeholder="Working email"/>
		      <input type="password" id="password" placeholder="Password"/>
		      <button id="login">LOGIN</button>
		    </div>
		  </div>
		</div>
	</div>
	<div class="properties_list">
		<p>Select the property to insert the script</p>
		<table id="properties_table" cellspacing="0">
		</table>
		<button id="insertscript">Insert the script</button>
	</div>
</div>
<script type="text/javascript">
	var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
	var selectedWidgetId = "";
	<?php
		$text = get_option("ultro_selected_widget_id");
		if($text){
			?>
				selectedWidgetId = "<?php echo $text; ?>";
			<?php
		}
	?>
</script>