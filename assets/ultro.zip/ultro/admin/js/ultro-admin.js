jQuery(document).ready(function(){
	jQuery("#login").click(function(e){
		e.preventDefault();
		var header = "Basic QjNuVExldGNYTXVCdTZOWlcxRk9yT0ZrUzZYOEFiZXNLMHhGOURCdDo=";
		var url = "https://dev-backend.ultro.io/oauth/token/";
		jQuery.ajax({
		    type: "POST",
		    url: url,
		    data: { grant_type: 'password', username: jQuery("#username").val(), password: jQuery("#password").val() },
		    beforeSend: function(xhr){
				xhr.setRequestHeader('authorization', header);
			},
			success: function(data) { 
				jQuery("#logout").show();
				loadProperties(data.access_token);
			}
		});
	});

	jQuery("#insertscript").click(function(e){
		e.preventDefault();
		var widgetId = jQuery(".select-dot.active");
		if(widgetId){
			widgetId = widgetId.parents("tr").data("widgetid");
		}
		else{
			return;
		}
		jQuery.ajax({
		    type: "POST",
		    url: ajaxurl,
		    data: { action : 'save_ultro_script', widgetId: widgetId },
			success: function(data) { 
				jQuery(".success_msg").fadeIn();
				setTimeout(function(){
					jQuery(".success_msg").fadeOut();
				}, 3000);
			}
		});
	});
});

function loadProperties(access_token){
	var access_token = access_token;
	var operationName = "companyProperty";
	var query = "{ data: companyProperty { id code title widgetSettings{ id } } }";
	var url = "https://dev-backend.ultro.io/graphql";
	var header = "Bearer "+access_token;
	jQuery.ajax({
	    type: "POST",
	    url: url,
	    data: { operationName: null, query: query},
	    beforeSend: function(xhr){
			xhr.setRequestHeader('authorization', header);
		},
		success: function(data) { 
			jQuery(".login-wrapper").hide();
			jQuery(".properties_list").show();
			showProperties(data.data);
		}
	});
}

function showProperties(properties){
	var html = "";
	for (var i = properties.data.length - 1; i >= 0; i--) {
		if(selectedWidgetId && selectedWidgetId == properties.data[i].widgetSettings.id){
			html += "<tr data-id="+properties.data[i].id+" data-selected='false' data-widgetid="+properties.data[i].widgetSettings.id+"><td>"+properties.data[i].title+" (<b>"+properties.data[i].code+"</b>)</td><td><div class='select-wrap'><div class='select-dot active'></div></div></td></tr>";	
		}
		else{
			html += "<tr data-id="+properties.data[i].id+" data-selected='false' data-widgetid="+properties.data[i].widgetSettings.id+"><td>"+properties.data[i].title+" (<b>"+properties.data[i].code+"</b>)</td><td><div class='select-wrap'><div class='select-dot'></div></div></td></tr>";
		}
	}
	jQuery("#properties_table").html(html);
	bindEvents();
}

function bindEvents(){
	jQuery(".select-wrap").click(function(e){
		e.preventDefault();
		jQuery(".select-dot").removeClass("active");
		jQuery(this).find(".select-dot").addClass("active");
	});
}