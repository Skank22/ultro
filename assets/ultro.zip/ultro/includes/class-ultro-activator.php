<?php

/**
 * Fired during plugin activation
 *
 * @link       https://www.ultro.io/
 * @since      1.0.0
 *
 * @package    Ultro
 * @subpackage Ultro/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Ultro
 * @subpackage Ultro/includes
 * @author     Ultro <rahul@ultro.io>
 */
class Ultro_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
